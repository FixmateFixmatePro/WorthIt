
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.querySelector("button");
  btn.addEventListener("click", () => {
    alert("Thanks for joining the WorthIt beta!");
  });
});
